<!doctype html> 
<html>
  <head>
    <meta charset="utf-8">
    <title>我的第一個PHP程式</title>
  </head>
  <body>
    <?php
      include_once("demo.inc");
    ?>
  </body>
</html>
<?php
//檔案名稱:demo.inc
// 單行註解comment:This is a single-line comment
# This is also a single-line comment

  echo("Hello World!");
  phpinfo();
  
 /*
 多行註解comment
This is a multiple-lines comment block
that spans over multiple
lines
*/
?>